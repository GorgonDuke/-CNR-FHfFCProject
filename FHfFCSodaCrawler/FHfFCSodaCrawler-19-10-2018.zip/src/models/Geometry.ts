export class Geometry {
  //  addedd: Date,
  coordinates: any;
  type: String;

  
};



export class Coordinates {
  lat: number;
  lng: number;
}

